module.exports = {
	extends: 'stylelint-config-recommended-vue',
}
